# Change log

## [1.0.2] - 2025-07-21 - improve concordance lab notebook wording

### Changed:

- provide guidance on Task 4 regarding quantitative claims about concordances
- clarify wording on Task 3 for semesters where Introduce Yourself dataset is 
released after labs

## [1.0.1] - 2025-07-17 - add import for get_nltk_corpus_sources

### Fixed:

- include import for get_nltk_corpus_sources in Lab 1.1 notebook
- corrected valid sort orders in Lab 2.1 notebook

## [1.0.0] - 2025-07-13 - Initial Release

### Added:

- notebooks for lab 1 and 2

## [Not released]

Prior to 2025, lab worksheets developed by Chris Thomson and Geoff Ford.
