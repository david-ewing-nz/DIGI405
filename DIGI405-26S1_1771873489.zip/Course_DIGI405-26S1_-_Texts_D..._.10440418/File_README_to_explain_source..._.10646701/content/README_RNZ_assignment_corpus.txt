# RNZ source data and corpora

This thematic corpus was constructed from a larger collection of RNZ news articles collected using the DigitalNZ API. News items without full text or a date of publication were excluded.

Word frequencies were obtained for the RNZ source corpus, and the most frequent climate-related unigrams and bigrams were examined. The terms "climate", "greenhouse", as well as selected collocates of "global" were chosen as the basis for selecting articles.

This regular expression was constructed to select articles for inclusion in the corpus:
 
str.contains(r'([Cc]limate | [Gg]reenhouse | [Gg]lobal\swarming | [Gg]lobal\stemperature[s]? | [Gg]lobal\semissions | [Gg]lobal\soil | [Gg]lobal\scarbon | [Gg]lobal\sheating)'

Also please note:

* Only articles published in 2008 or later were included.
* Articles up to the collection of data in 2024 have been included.
* Most columns with values from the DigitalNZ API are included. A year column has been added. 
* An "is_international" column has been inferred from the URL structure. The value of "is_international" is True if the URL contains ".nz/news/world/" or ".nz/international/". Articles with "is_international" value set to False are considered national news (i.e. related to domestic New Zealand reporting).
* Separate CSV files are available for the international and national segments based on the "is_international" column.

The CSV files are available on AKO LEARN and are accessible in the /srv/source-data/ directory on JupyterHub.

Corpora have been created from the source and are available now on the class JupyterHub. These can be loaded as follows:
rnz_climate = Corpus().load('/srv/corpora/rnz-climate.corpus')
rnz_climate_national = Corpus().load('/srv/corpora/rnz-climate-national.corpus')
rnz_climate_international = Corpus().load('/srv/corpora/rnz-climate-international.corpus')

For the assignment you can just use the main RNZ climate corpus, but the national/international corpora may be interesting.

## Note on RNZ reference corpus

A list corpus for RNZ based on all available full-text articles between 2002 and 2024 has been released on the class JupyterHub. You can load it like this:

rnz_reference_corpus = ListCorpus().load('/srv/corpora/rnz.listcorpus')

The source data for this corpus will not be released to the class.

