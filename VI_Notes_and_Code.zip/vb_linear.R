# Mean-Field Variational Bayes for Linear Regression
# Conjugate Normal-Inverse-Gamma model with coordinate ascent updates

#' Mean-Field VB for Linear Regression
#'
#' @param X Design matrix (N x K) including intercept
#' @param y Response vector (N x 1)
#' @param prior_mu Prior mean for beta (K x 1)
#' @param prior_sigma Prior SD for beta (scalar)
#' @param prior_a Shape parameter for sigma prior
#' @param prior_b Rate parameter for sigma prior
#' @param max_iter Maximum iterations
#' @param tol Convergence tolerance for ELBO
#' @param verbose Print progress
#'
#' @return List with variational parameters and ELBO history
vb_linear_regression <- function(X, y, 
                                   prior_mu = NULL,
                                   prior_sigma = 10,
                                   prior_a = 2,
                                   prior_b = 2,
                                   max_iter = 1000,
                                   tol = 1e-6,
                                   verbose = TRUE) {
  
  # Dimensions
  N <- nrow(X)
  K <- ncol(X)
  
  # Default prior mean
  if (is.null(prior_mu)) {
    prior_mu <- rep(0, K)
  }
  
  # Prior precision matrix for beta
  Lambda_0 <- diag(K) / (prior_sigma^2)
  
  # Initialize variational parameters
  # q(beta) = Normal(mu_beta, Sigma_beta)
  mu_beta <- solve(t(X) %*% X) %*% t(X) %*% y  # Start with OLS
  Sigma_beta <- solve(t(X) %*% X + Lambda_0)
  
  # q(sigma^2) = Inverse-Gamma(a_sigma, b_sigma)
  a_sigma <- prior_a + N/2
  b_sigma <- prior_b  # Will be updated
  
  # ELBO history
  elbo_history <- numeric(max_iter)
  
  # Coordinate ascent iterations
  for (iter in 1:max_iter) {
    
    # Update q(beta) | q(sigma^2)
    # E[1/sigma^2] = a_sigma / b_sigma
    E_inv_sigma2 <- a_sigma / b_sigma
    
    Sigma_beta <- solve(E_inv_sigma2 * (t(X) %*% X) + Lambda_0)
    mu_beta <- Sigma_beta %*% (E_inv_sigma2 * (t(X) %*% y) + Lambda_0 %*% prior_mu)
    
    # Update q(sigma^2) | q(beta)
    # E[||y - X*beta||^2] accounting for uncertainty in beta
    residuals <- y - X %*% mu_beta
    E_sse <- sum(residuals^2) + sum(diag(t(X) %*% X %*% Sigma_beta))
    
    a_sigma <- prior_a + N/2
    b_sigma <- prior_b + E_sse/2
    
    # Compute ELBO (Evidence Lower Bound)
    elbo <- compute_elbo(X, y, mu_beta, Sigma_beta, a_sigma, b_sigma,
                         prior_mu, Lambda_0, prior_a, prior_b)
    elbo_history[iter] <- elbo
    
    # Check convergence
    if (iter > 1) {
      elbo_change <- abs(elbo - elbo_history[iter - 1])
      if (verbose && iter %% 100 == 0) {
        cat(sprintf("Iteration %d: ELBO = %.4f, Change = %.6f\n", 
                    iter, elbo, elbo_change))
      }
      if (elbo_change < tol) {
        if (verbose) {
          cat(sprintf("Converged at iteration %d\n", iter))
        }
        elbo_history <- elbo_history[1:iter]
        break
      }
    }
  }
  
  # Return variational parameters
  list(
    mu_beta = as.vector(mu_beta),
    Sigma_beta = Sigma_beta,
    a_sigma = a_sigma,
    b_sigma = b_sigma,
    E_beta = as.vector(mu_beta),
    E_sigma2 = b_sigma / (a_sigma - 1),  # Mean of Inverse-Gamma
    E_sigma = sqrt(b_sigma / (a_sigma - 1)),
    Var_beta = diag(Sigma_beta),
    SD_beta = sqrt(diag(Sigma_beta)),
    Var_sigma2 = b_sigma^2 / ((a_sigma - 1)^2 * (a_sigma - 2)),  # Var of Inverse-Gamma
    elbo = elbo_history,
    converged = iter < max_iter,
    iterations = iter
  )
}

#' Compute ELBO (Evidence Lower Bound)
#'
#' @keywords internal
compute_elbo <- function(X, y, mu_beta, Sigma_beta, a_sigma, b_sigma,
                         prior_mu, Lambda_0, prior_a, prior_b) {
  
  N <- nrow(X)
  K <- ncol(X)
  
  # E[log p(y | beta, sigma^2)]
  E_inv_sigma2 <- a_sigma / b_sigma
  E_log_sigma2 <- digamma(a_sigma) - log(b_sigma)
  
  residuals <- y - X %*% mu_beta
  E_sse <- sum(residuals^2) + sum(diag(t(X) %*% X %*% Sigma_beta))
  
  E_log_like <- -N/2 * log(2*pi) - N/2 * E_log_sigma2 - 
                E_inv_sigma2 * E_sse / 2
  
  # E[log p(beta)]
  diff_beta <- mu_beta - prior_mu
  E_log_prior_beta <- -K/2 * log(2*pi) - 
                      0.5 * determinant(solve(Lambda_0), logarithm = TRUE)$modulus -
                      0.5 * (t(diff_beta) %*% Lambda_0 %*% diff_beta + 
                             sum(diag(Lambda_0 %*% Sigma_beta)))
  
  # E[log p(sigma^2)]
  E_log_prior_sigma2 <- prior_a * log(prior_b) - lgamma(prior_a) -
                        (prior_a + 1) * E_log_sigma2 - prior_b * E_inv_sigma2
  
  # Entropy H[q(beta)]
  H_beta <- 0.5 * determinant(Sigma_beta, logarithm = TRUE)$modulus +
            K/2 * (1 + log(2*pi))
  
  # Entropy H[q(sigma^2)]
  H_sigma2 <- a_sigma + log(b_sigma) + lgamma(a_sigma) -
              (1 + a_sigma) * digamma(a_sigma)
  
  # ELBO = E[log p(y, beta, sigma^2)] - E[log q(beta, sigma^2)]
  elbo <- E_log_like + E_log_prior_beta + E_log_prior_sigma2 + 
          H_beta + H_sigma2
  
  return(as.numeric(elbo))
}

#' Sample from VB Posterior Approximation
#'
#' @param vb_fit Output from vb_linear_regression
#' @param n_samples Number of samples to draw
#' @param seed Random seed
#'
#' @return Matrix of posterior samples (n_samples x (K+1))
#'         Columns: beta[1], ..., beta[K], sigma
sample_vb_posterior <- function(vb_fit, n_samples = 2000, seed = 82171165) {
  set.seed(seed)
  
  K <- length(vb_fit$mu_beta)
  samples <- matrix(NA, nrow = n_samples, ncol = K + 1)
  
  # Sample beta from multivariate normal
  library(MASS)
  beta_samples <- mvrnorm(n = n_samples, 
                          mu = vb_fit$mu_beta, 
                          Sigma = vb_fit$Sigma_beta)
  samples[, 1:K] <- beta_samples
  
  # Sample sigma^2 from Inverse-Gamma, then take sqrt
  # InvGamma(a, b) = 1/Gamma(a, 1/b)
  sigma2_samples <- 1 / rgamma(n_samples, 
                               shape = vb_fit$a_sigma, 
                               rate = vb_fit$b_sigma)
  samples[, K + 1] <- sqrt(sigma2_samples)
  
  colnames(samples) <- c(paste0("beta[", 1:K, "]"), "sigma")
  
  return(samples)
}
