# Mixture of Gaussians VI with Mixture Approximation
# q(θ) = Σᵢ wᵢ N(μᵢ, Σᵢ)
# 
# For a mixture of Gaussians model, the posterior can be multi-modal
# (label-switching), so a mixture approximation can capture this better
# than a single Gaussian.

library(mvtnorm)
library(glue)

#' Mixture of Gaussians VI with Mixture Approximation
#'
#' @param y_train Training data (N x D matrix)
#' @param K Number of mixture components in the data model
#' @param K_q Number of mixture components in the approximation q(θ)
#' @param max_iter Maximum VI iterations
#' @param n_samples Number of samples for gradient estimation
#' @param learning_rate Step size for natural gradient
#' @param tol Convergence tolerance for ELBO
#' @param verbose Print progress
#' @param seed Random seed
#'
#' @return List with:
#'   - weights: Mixture weights w_i (K_q)
#'   - means: List of mean vectors μ_i (K_q elements)
#'   - covs: List of covariance matrices Σ_i (K_q elements)
#'   - elbo_hist: ELBO history
#'   - converged: Convergence flag
#'
#' @param init_weights Optional: initial weights for warm-start (length K_q)
#' @param init_means Optional: initial means for warm-start (list of K_q vectors)
#' @param init_covs Optional: initial covariances for warm-start (list of K_q matrices)
vb_mog_mixture <- function(y_train,
                           K,
                           K_q          = 3,
                           max_iter     = 5000,
                           n_samples    = 200,
                           learning_rate = 0.001,
                           tol          = 1e-4,
                           verbose      = TRUE,
                           seed         = 82171165,
                           init_weights = NULL,
                           init_means   = NULL,
                           init_covs    = NULL) {
  
  set.seed(seed)
  
  N <- nrow(y_train)
  D <- ncol(y_train)
  
  # Total parameter dimension for MoG model:
  # - K mixture weights (K-1 free params, simplex)
  # - K means (K*D params)
  # - K covariances (K*D*(D+1)/2 params, each is symmetric)
  # 
  # For simplicity, work in unconstrained space:
  # - log-weights: K-1 params (softmax to get simplex)
  # - means: K*D params
  # - log-cholesky: K*D*(D+1)/2 params (Cholesky factors)
  
  n_params_theta   <- (K - 1)                  # log weights (unconstrained)
  n_params_mu      <- K * D                    # means
  n_params_sigma   <- K * D * (D + 1) / 2      # Cholesky factors (lower tri)
  n_params_total   <- n_params_theta + n_params_mu + n_params_sigma
  
  # Check for warm-start
  warm_start <- !is.null(init_weights) && !is.null(init_means) && !is.null(init_covs)
  
  if (T) {
    cat(glue("Mixture VI Setup:\n"))
    cat(glue("  Data: N={N}, D={D}\n"))
    cat(glue("  Model components: K={K}\n"))
    cat(glue("  Approximation components: K_q={K_q}\n"))
    cat(glue("  Total parameters: {n_params_total}\n"))
    cat(glue("  Warm-start: {warm_start}\n\n"))
  }
  
  # ---- Initialise q(θ) = Σᵢ wᵢ N(μᵢ, Σᵢ) ----
  
  if (warm_start) {
    # Use provided initialisation
    weights <- init_weights
    means   <- init_means
    covs    <- init_covs
    if (verbose) cat("Using warm-start from previous fit\n\n")
  } else {
    # Fresh initialisation
    # Weights: start uniform
    weights <- rep(1 / K_q, K_q)
    
    # Means: random initialisation around 0
    means <- lapply(1:K_q, function(i) {
      rnorm(n_params_total, mean = 0, sd = 0.5)
    })
    
    # Covariances: start with identity
    covs <- lapply(1:K_q, function(i) {
      diag(n_params_total)
    })
    if (verbose) cat("Using fresh random initialisation\n\n")
  }
  
  elbo_hist <- numeric(max_iter)
  converged <- FALSE
  
  # ---- Helper: unpack parameters from vector ----
  unpack_theta <- function(theta_vec) {
    idx <- 1
    
    # Log-weights (K-1)
    log_w_raw <- theta_vec[idx:(idx + n_params_theta - 1)]
    idx <- idx + n_params_theta
    log_w <- c(log_w_raw, 0)  # add reference
    w <- exp(log_w) / sum(exp(log_w))
    
    # Means (K*D)
    mu_mat <- matrix(theta_vec[idx:(idx + n_params_mu - 1)], nrow = K, ncol = D)
    idx <- idx + n_params_mu
    
    # Cholesky factors (K covariances)
    Sigma_array <- array(0, dim = c(D, D, K))
    for (k in 1:K) {
      # Extract lower-triangular Cholesky
      L <- matrix(0, D, D)
      L[lower.tri(L, diag = TRUE)] <- theta_vec[idx:(idx + D*(D+1)/2 - 1)]
      idx <- idx + D * (D + 1) / 2
      
      Sigma_array[, , k] <- L %*% t(L)
    }
    
    list(weights = w, mu = mu_mat, Sigma = Sigma_array)
  }
  
  # ---- Helper: log p(y | θ) - mixture likelihood ----
  log_likelihood <- function(y_mat, params) {
    w <- params$weights
    mu <- params$mu
    Sigma <- params$Sigma
    
    loglik <- 0
    for (n in 1:nrow(y_mat)) {
      lps <- numeric(K)
      for (k in 1:K) {
        lps[k] <- log(w[k]) + dmvnorm(y_mat[n, ], mean = mu[k, ], sigma = Sigma[, , k], log = TRUE)
      }
      # log-sum-exp
      m <- max(lps)
      loglik <- loglik + m + log(sum(exp(lps - m)))
    }
    loglik
  }
  
  # ---- Helper: log prior p(θ) ----
  log_prior <- function(params) {
    # Simple priors:
    # - Dirichlet(1,...,1) on weights -> log p(w) = 0 (up to constant)
    # - N(0, 5²) on means
    # - LKJ(2) on correlation + log-normal on scales (approximate)
    
    lp <- 0
    
    # Means prior
    lp <- lp + sum(dnorm(params$mu, mean = 0, sd = 5, log = TRUE))
    
    # Simplified covariance prior (just penalize large values)
    for (k in 1:K) {
      eig <- eigen(params$Sigma[, , k], only.values = TRUE)$values
      if (any(eig <= 0)) return(-Inf)  # ensure positive definite
      lp <- lp + sum(dnorm(log(eig), mean = 0, sd = 1, log = TRUE))
    }
    
    lp
  }
  
  # ---- Helper: sample from q(θ) ----
  sample_q <- function(n_samp) {
    # Sample component indices
    comp <- sample(1:K_q, size = n_samp, replace = TRUE, prob = weights)
    
    # Sample from selected components
    samples <- matrix(0, nrow = n_samp, ncol = n_params_total)
    for (i in 1:n_samp) {
      k <- comp[i]
      samples[i, ] <- mvrnorm(1, mu = means[[k]], Sigma = covs[[k]])
    }
    
    list(samples = samples, components = comp)
  }
  
  # ---- Helper: ELBO computation ----
  compute_elbo <- function(n_samp = 500) {
    samp <- sample_q(n_samp)
    theta_samples <- samp$samples
    
    log_joint <- numeric(n_samp)
    log_q     <- numeric(n_samp)
    
    for (s in 1:n_samp) {
      theta_s <- theta_samples[s, ]
      params_s <- unpack_theta(theta_s)
      
      # log p(y, θ)
      log_joint[s] <- log_likelihood(y_train, params_s) + log_prior(params_s)
      
      # log q(θ) = log Σᵢ wᵢ N(θ | μᵢ, Σᵢ)
      log_densities <- numeric(K_q)
      for (i in 1:K_q) {
        log_densities[i] <- log(weights[i]) + dmvnorm(theta_s, mean = means[[i]], sigma = covs[[i]], log = TRUE)
      }
      m <- max(log_densities)
      log_q[s] <- m + log(sum(exp(log_densities - m)))
    }
    
    mean(log_joint - log_q)
  }
  
  # ---- Main VI loop ----
  if (verbose) cat("Starting VI optimisation...\n")
  
  iter_start_time <- Sys.time()
  prev_iter_time  <- iter_start_time
  
  for (iter in 1:max_iter) {
    
    iter_time <- Sys.time()
    
    # Compute ELBO only periodically (expensive operation)
    # Check every 10 iterations, or at first and last
    compute_elbo_now <- (iter == 1) || (iter == max_iter) || (iter %% 10 == 0)
    
    if (compute_elbo_now) {
      tryCatch({
        # Use fewer samples for ELBO to speed up
        elbo_val <- compute_elbo(n_samp = 50)
        
        # Check for numerical issues
        if (is.na(elbo_val) || is.infinite(elbo_val)) {
          if (verbose) cat(glue("Warning: ELBO is {elbo_val} at iter {iter}, using previous value\n"))
          if (iter > 1) {
            elbo_hist[iter] <- elbo_hist[iter - 1]
          } else {
            elbo_hist[iter] <- -1e10  # large negative number
          }
        } else {
          elbo_hist[iter] <- elbo_val
        }
      }, error = function(e) {
        if (verbose) cat(glue("Error computing ELBO at iter {iter}: {e$message}\n"))
        if (iter > 1) {
          elbo_hist[iter] <- elbo_hist[iter - 1]
        } else {
          elbo_hist[iter] <- -1e10
        }
      })
    } else {
      # Reuse previous ELBO value for iterations in between
      if (iter > 1) {
        elbo_hist[iter] <- elbo_hist[iter - 1]
      }
    }
    
    # Always compute delta time
    delta_t <- as.numeric(difftime(iter_time, prev_iter_time, units = "secs"))
    
    # Diagnostic: Check for ELBO decrease (divergence warning)
    if (compute_elbo_now && iter > 1) {
      elbo_decrease <- elbo_hist[iter] - elbo_hist[iter - 1]
      if (elbo_decrease < -10) {  # Significant decrease
        warning(glue("DIVERGENCE WARNING at iter {iter}: ELBO decreased by {round(abs(elbo_decrease), 2)}. Consider reducing learning_rate."))
      }
    }
    
    if (verbose && (iter %% 100 == 0 || iter == 1)) {
      cat(glue("Iter {sprintf('%3d', iter)}/{max_iter}: ELBO = {round(elbo_hist[iter], 3)} | Δt = {round(delta_t, 2)}s\n\n"))
    } else if (verbose) {
      # Show delta time for all other iterations
      cat(glue("Iter {sprintf('%3d', iter)}/{max_iter}:                  | Δt = {round(delta_t, 2)}s\n"))
    } else if (!verbose && compute_elbo_now) {
      # When not verbose, show only ELBO iterations with timing
      cat(glue("Iter {sprintf('%4d', iter)}/{max_iter}: ELBO = {round(elbo_hist[iter], 3)} | Δt = {round(delta_t, 2)}s\n"))
    }
    
    # Check convergence (only when ELBO was computed)
    if (compute_elbo_now && iter > 10) {
      elbo_change <- abs(elbo_hist[iter] - elbo_hist[iter - 1])
      if (elbo_change < tol) {
        converged <- TRUE
        if (verbose) cat(glue("Converged at iteration {iter}\n"))
        break
      }
    }
    
    # ---- Simplified EM-style update ----
    # Instead of expensive numerical gradients, use expectation-maximization:
    # E-step: assign samples to components
    # M-step: update component parameters
    
    prev_iter_time <- iter_time  # Update for next iteration
    
    samp <- sample_q(n_samples)
    theta_samples <- samp$samples
    
    # Compute responsibilities (soft assignments)
    # For each sample, compute p(component i | θ)
    responsibilities <- matrix(0, nrow = n_samples, ncol = K_q)
    
    if (verbose) {
      cat(glue("\n  [Iter {sprintf('%3d', iter)}] Computing responsibilities for {sprintf('%3d', n_samples)}  samples...\n"))
    }  
    
    for (s in 1:n_samples) {
      
      # Progress indicator every 20 samples
      if (verbose && s %% 20 == 0) {
        cat(glue("    Sample {sprintf('%3d', s)}/{n_samples}...\n"))
      }
      
      theta_s <- theta_samples[s, ]
      params_s <- tryCatch({
        unpack_theta(theta_s)
      }, error = function(e) NULL)
      
      if (is.null(params_s)) {
        responsibilities[s, ] <- 1 / K_q  # uniform if error
        next
      }
      
      # Compute log p(y | θ_s) + log p(θ_s) for weighting
      log_post <- tryCatch({
        log_likelihood(y_train, params_s) + log_prior(params_s)
      }, error = function(e) -1e10)
      
      if (is.infinite(log_post) || is.na(log_post)) {
        log_post <- -1e10
      }
      
      # Weight by posterior (samples with higher posterior get more weight)
      # This helps components focus on high-probability regions
      for (i in 1:K_q) {
        log_qi <- tryCatch({
          dmvnorm(theta_s, mean = means[[i]], sigma = covs[[i]], log = TRUE)
        }, error = function(e) -1e10)
        
        if (is.na(log_qi) || is.infinite(log_qi)) {
          log_qi <- -1e10
        }
        
        responsibilities[s, i] <- exp(log_qi + 0.1 * log_post)  # soft weight
      }
      
      # Normalise responsibilities (handle edge cases)
      resp_sum <- sum(responsibilities[s, ])
      if (is.na(resp_sum) || resp_sum == 0 || is.infinite(resp_sum)) {
        responsibilities[s, ] <- 1 / K_q  # uniform fallback
      } else {
        responsibilities[s, ] <- responsibilities[s, ] / resp_sum
      }
    }
    
    if (verbose) {
      cat(glue("  [Iter {sprintf('%3d', iter)}] Updating {K_q} mixture components...\n\n"))
    }
    
    # M-step: update component parameters using weighted samples
    for (i in 1:K_q) {
      # Effective sample size for component i
      n_eff <- sum(responsibilities[, i])
      
      # Handle NA or very small n_eff
      if (is.na(n_eff) || n_eff < 5) next  # skip if too few samples
      
      # Weighted mean
      new_mean <- colSums(responsibilities[, i] * theta_samples) / n_eff
      
      # Smooth update (avoid large jumps)
      means[[i]] <- 0.9 * means[[i]] + 0.1 * new_mean
      
      # Weighted covariance
      centered <- sweep(theta_samples, 2, means[[i]], "-")
      new_cov  <- t(centered) %*% diag(responsibilities[, i]) %*% centered / n_eff
      
      # Regularise and smooth update
      new_cov <- new_cov + diag(1e-4, n_params_total)  # ridge
      covs[[i]] <- 0.95 * covs[[i]] + 0.05 * new_cov
      
      # Ensure positive definite eigenvalues
      eig       <- eigen(covs[[i]], symmetric = TRUE)
      min_eig   <- min(eig$values)
      max_eig   <- max(eig$values)
      cond_num  <- max_eig / max(min_eig, 1e-10)
      
      # Diagnostic: Warn if condition number too large
      if (verbose && iter %% 50 == 0 && cond_num > 1e6) {
        cat(glue("  WARNING: Component {i} condition number = {round(cond_num, 0)} (ill-conditioned)\n"))
      }
      
      covs[[i]] <- eig$vectors %*% diag(pmax(eig$values, 1e-5)) %*% t(eig$vectors)
    }
    
    # Update weights based on responsibilities
    new_weights <- colMeans(responsibilities)
    weights <- 0.9 * weights + 0.1 * new_weights
    weights <- weights / sum(weights)  # renormalise
  }
  
  list(
    weights   = weights,
    means     = means,
    covs      = covs,
    elbo_hist = elbo_hist[1:iter],
    converged = converged,
    n_iter    = iter,
    K_q       = K_q
  )
}


#' Draw samples from fitted mixture approximation q(θ)
#'
#' @param fit Output from vb_mog_mixture()
#' @param n_samples Number of samples to draw
#'
#' @return Matrix of samples (n_samples x n_params)
sample_mixture_q <- function(fit, n_samples = 1000) {
  K_q <- fit$K_q
  weights <- fit$weights
  means <- fit$means
  covs <- fit$covs
  
  n_params <- length(means[[1]])
  
  # Sample component assignments
  comp <- sample(1:K_q, size = n_samples, replace = TRUE, prob = weights)
  
  # Sample from selected components
  samples <- matrix(0, nrow = n_samples, ncol = n_params)
  for (i in 1:n_samples) {
    k <- comp[i]
    samples[i, ] <- MASS::mvrnorm(1, mu = means[[k]], Sigma = covs[[k]])
  }
  
  samples
}
