# Exact Conjugate Posterior for Linear Regression
# Analytical Normal-Inverse-Gamma solution

#' Compute Exact Conjugate Posterior for Linear Regression
#'
#' For conjugate Normal-Inverse-Gamma prior, derives exact posterior parameters
#'
#' @param X Design matrix (N x K) including intercept
#' @param y Response vector (N x 1)
#' @param prior_mu Prior mean for beta (K x 1)
#' @param prior_sigma Prior SD for beta (scalar)
#' @param prior_a Shape parameter for sigma^2 prior (Inverse-Gamma)
#' @param prior_b Scale parameter for sigma^2 prior (Inverse-Gamma)
#'
#' @return List with exact posterior parameters
exact_linear_posterior <- function(X, y, 
                                    prior_mu = NULL,
                                    prior_sigma = 10,
                                    prior_a = 2,
                                    prior_b = 2) {
  
  # Dimensions
  N <- nrow(X)
  K <- ncol(X)
  
  # Default prior mean
  if (is.null(prior_mu)) {
    prior_mu <- rep(0, K)
  }
  
  # Prior precision matrix for beta
  Lambda_0 <- diag(K) / (prior_sigma^2)
  
  # Posterior parameters for beta | sigma^2
  # Sigma_n = (Lambda_0 + X'X)^{-1}
  Sigma_n <- solve(Lambda_0 + t(X) %*% X)
  
  # mu_n = Sigma_n (Lambda_0 mu_0 + X'y)
  mu_n <- Sigma_n %*% (Lambda_0 %*% prior_mu + t(X) %*% y)
  
  # Posterior parameters for sigma^2
  # a_n = a_0 + N/2
  a_n <- prior_a + N/2
  
  # b_n = b_0 + 0.5 * (y'y - mu_n' Sigma_n^{-1} mu_n)
  b_n <- prior_b + 0.5 * (sum(y^2) - t(mu_n) %*% solve(Sigma_n) %*% mu_n)
  b_n <- as.numeric(b_n)
  
  return(list(
    mu_n = as.vector(mu_n),
    Sigma_n = Sigma_n,
    a_n = a_n,
    b_n = b_n,
    # For marginal posterior of beta (multivariate t)
    df = 2 * a_n,
    scale_matrix = (b_n / a_n) * Sigma_n
  ))
}


#' Sample from Exact Conjugate Posterior
#'
#' Generates samples from exact Normal-Inverse-Gamma posterior
#' Samples sigma^2 from Inverse-Gamma, then beta | sigma^2 from Normal
#'
#' @param exact_post Output from exact_linear_posterior
#' @param n_samples Number of samples to draw
#'
#' @return Matrix (n_samples x (K+1)) with columns [beta_1, ..., beta_K, sigma]
sample_exact_posterior <- function(exact_post, n_samples = 2000) {
  
  K <- length(exact_post$mu_n)
  samples <- matrix(NA, nrow = n_samples, ncol = K + 1)
  
  set.seed(82171165)
  
  for (i in 1:n_samples) {
    # Sample sigma^2 from Inverse-Gamma(a_n, b_n)
    # Using relation: if X ~ Gamma(a, b), then 1/X ~ Inverse-Gamma(a, b)
    sigma2 <- 1 / rgamma(1, shape = exact_post$a_n, rate = exact_post$b_n)
    
    # Sample beta | sigma^2 from Normal(mu_n, sigma^2 * Sigma_n)
    beta <- MASS::mvrnorm(n = 1, 
                          mu = exact_post$mu_n, 
                          Sigma = sigma2 * exact_post$Sigma_n)
    
    # Store: [beta_1, ..., beta_K, sigma]
    samples[i, ] <- c(beta, sqrt(sigma2))
  }
  
  # Column names
  colnames(samples) <- c(paste0("beta", 1:K), "sigma")
  
  return(samples)
}


#' Sample from Marginal Posterior of Beta (Multivariate t)
#'
#' Alternative sampling from marginal beta distribution (integrating out sigma^2)
#' This gives multivariate t-distribution
#'
#' @param exact_post Output from exact_linear_posterior
#' @param n_samples Number of samples to draw
#'
#' @return Matrix (n_samples x K) with beta samples
sample_marginal_beta <- function(exact_post, n_samples = 2000) {
  
  K <- length(exact_post$mu_n)
  
  set.seed(82171165)
  
  # Multivariate t with df = 2*a_n, location = mu_n, scale = (b_n/a_n) * Sigma_n
  samples <- LaplacesDemon::rmvt(n = n_samples,
                                  mu = exact_post$mu_n,
                                  S = exact_post$scale_matrix,
                                  df = exact_post$df)
  
  colnames(samples) <- paste0("beta", 1:K)
  
  return(samples)
}
