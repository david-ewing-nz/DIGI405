# Mixture of Gaussians VI with Mean-Field Approximation
# q(θ) = q(w) · q(μ₁) · ... · q(μ_K) · q(Σ₁) · ... · q(Σ_K)
# 
# Mean-field factorisation: each parameter has independent approximation
# Cannot capture correlations between parameters

library(mvtnorm)
library(glue)

#' Mixture of Gaussians VI with Mean-Field Approximation
#'
#' @param y_train Training data (N x D matrix)
#' @param K Number of mixture components in the data model
#' @param max_iter Maximum VI iterations (coordinate ascent)
#' @param tol Convergence tolerance for ELBO
#' @param verbose Print progress
#' @param seed Random seed
#'
#' @return List with:
#'   - alpha: Dirichlet parameters for q(w)
#'   - m_k: List of K mean vectors for q(μ_k)
#'   - S_k: List of K covariances for q(μ_k)
#'   - nu_k: Degrees of freedom for q(Σ_k)
#'   - Psi_k: Scale matrices for q(Σ_k)
#'   - responsibilities: Final E[z_nk] (N x K)
#'   - elbo_hist: ELBO history
#'   - converged: Convergence flag
vb_mog_meanfield <- function(y_train,
                             K,
                             max_iter = 1000,
                             tol      = 1e-4,
                             verbose  = TRUE,
                             seed     = 82171165) {
  
  set.seed(seed)
  
  N <- nrow(y_train)
  D <- ncol(y_train)
  
  if (verbose) {
    cat(glue("Mean-Field VI Setup:\n"))
    cat(glue("  Data: N={N}, D={D}\n"))
    cat(glue("  Model components: K={K}\n"))
    cat(glue("  Approximation: q(θ) = q(w) · ∏ q(μ_k) · ∏ q(Σ_k) (factorised)\n\n"))
  }
  
  # Priors
  alpha_0 <- rep(1, K)             # Symmetric Dirichlet prior on weights
  m_0     <- rep(0, D)             # Prior mean for component means
  kappa_0 <- 0.01                  # Prior precision (weak)
  nu_0    <- D + 2                 # Prior degrees of freedom
  Psi_0   <- diag(D)               # Prior scale matrix
  
  # Initialisation via k-means
  km      <- kmeans(y_train, centers = K, nstart = 10)
  r       <- matrix(0, N, K)
  for (n in 1:N) {
    r[n, km$cluster[n]] <- 1
  }
  
  # Initialise variational parameters
  alpha <- alpha_0 + colSums(r)
  
  m_k   <- vector("list", K)
  S_k   <- vector("list", K)
  nu_k  <- numeric(K)
  Psi_k <- vector("list", K)
  
  for (k in 1:K) {
    m_k[[k]]   <- km$centers[k, ]
    S_k[[k]]   <- diag(D) * 0.1
    nu_k[k]    <- nu_0 + sum(r[, k])
    Psi_k[[k]] <- Psi_0
  }
  
  elbo_hist <- numeric(max_iter)
  converged <- FALSE
  
  if (verbose) cat("Starting coordinate ascent...\n")
  
  for (iter in 1:max_iter) {
    
    # E-step: update responsibilities r_nk = E[z_nk]
    log_rho <- matrix(0, N, K)
    
    for (k in 1:K) {
      E_log_pi_k <- digamma(alpha[k]) - digamma(sum(alpha))
      
      E_log_det_Sigma_k <- sum(digamma((nu_k[k] + 1 - 1:D) / 2)) + D * log(2) + 
                           determinant(Psi_k[[k]], logarithm = TRUE)$modulus[1]
      
      E_Sigma_k_inv <- nu_k[k] * solve(Psi_k[[k]])
      
      for (n in 1:N) {
        diff        <- y_train[n, ] - m_k[[k]]
        mahalanobis <- t(diff) %*% E_Sigma_k_inv %*% diff + 
                       sum(diag(E_Sigma_k_inv %*% S_k[[k]]))
        
        log_rho[n, k] <- E_log_pi_k + 0.5 * E_log_det_Sigma_k - 
                         0.5 * (D * log(2 * pi) + mahalanobis)
      }
    }
    
    log_rho_max <- apply(log_rho, 1, max)
    r           <- exp(log_rho - log_rho_max)
    r           <- r / rowSums(r)
    
    # M-step: update variational parameters
    N_k <- colSums(r)
    
    # Update q(w): Dirichlet(alpha)
    alpha <- alpha_0 + N_k
    
    # Update q(μ_k) and q(Σ_k) for each component
    for (k in 1:K) {
      # Weighted mean
      x_bar_k <- colSums(r[, k] * y_train) / (N_k[k] + 1e-10)
      
      # Update q(μ_k): Normal(m_k, S_k)
      kappa_k  <- kappa_0 + N_k[k]
      m_k[[k]] <- (kappa_0 * m_0 + N_k[k] * x_bar_k) / kappa_k
      S_k[[k]] <- diag(D) / kappa_k
      
      # Update q(Σ_k): parameters nu_k, Psi_k
      nu_k[k] <- nu_0 + N_k[k]
      
      S_k_weighted <- matrix(0, D, D)
      for (n in 1:N) {
        diff          <- y_train[n, ] - x_bar_k
        S_k_weighted  <- S_k_weighted + r[n, k] * (diff %*% t(diff))
      }
      
      diff_m      <- x_bar_k - m_0
      Psi_k[[k]]  <- Psi_0 + S_k_weighted + 
                     (kappa_0 * N_k[k] / kappa_k) * (diff_m %*% t(diff_m))
    }
    
    # Compute ELBO (simplified version for convergence check)
    elbo <- 0
    
    for (n in 1:N) {
      elbo <- elbo + sum(r[n, ] * log_rho[n, ])
      elbo <- elbo - sum(r[n, ] * log(r[n, ] + 1e-10))
    }
    
    elbo_hist[iter] <- elbo
    
    # Check convergence
    if (iter > 1) {
      elbo_change <- abs(elbo - elbo_hist[iter - 1])
      
      if (verbose && iter %% 50 == 0) {
        cat(glue("Iter {iter}: ELBO = {round(elbo, 2)}, Change = {round(elbo_change, 6)}\n"))
      }
      
      if (elbo_change < tol) {
        converged <- TRUE
        if (verbose) cat(glue("Converged at iteration {iter}\n"))
        break
      }
    }
  }
  
  if (!converged && verbose) {
    cat(glue("Did not converge after {max_iter} iterations\n"))
  }
  
  list(
    alpha            = alpha,
    m_k              = m_k,
    S_k              = S_k,
    nu_k             = nu_k,
    Psi_k            = Psi_k,
    responsibilities = r,
    elbo_hist        = elbo_hist[1:iter],
    converged        = converged,
    K                = K,
    D                = D
  )
}

#' Sample from mean-field posterior
#'
#' @param fit Output from vb_mog_meanfield
#' @param n_samples Number of samples to draw
#'
#' @return List with mu (K x D matrix), Sigma (D x D x K array), theta (K vector)
sample_meanfield_posterior <- function(fit, n_samples = 1000) {
  
  K <- fit$K
  D <- fit$D
  
  # Sample weights from Dirichlet
  theta <- MCMCpack::rdirichlet(n_samples, fit$alpha)
  
  # Sample means and covariances for each component
  mu_samples    <- array(NA, dim = c(n_samples, K, D))
  Sigma_samples <- array(NA, dim = c(n_samples, K, D, D))
  
  for (k in 1:K) {
    # Sample covariance from q(Σ_k)
    Sigma_k_samples <- MCMCpack::riwish(n_samples, fit$nu_k[k], fit$Psi_k[[k]])
    
    # Sample means from q(μ_k) for each sampled Σ_k
    for (s in 1:n_samples) {
      mu_samples[s, k, ]       <- mvrnorm(1, fit$m_k[[k]], fit$S_k[[k]])
      Sigma_samples[s, k, , ]  <- Sigma_k_samples[, , s]
    }
  }
  
  list(
    theta = theta,
    mu    = mu_samples,
    Sigma = Sigma_samples
  )
}
